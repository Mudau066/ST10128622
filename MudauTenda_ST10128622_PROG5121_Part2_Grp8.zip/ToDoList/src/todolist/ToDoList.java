/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package todolist;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

/**
 *
 * @author Tenda
 */

class Student
{
    private int studentNo;
    private String studentSurname;
    private String studentName;
    private String program;
    
    Student(int studentNo, String studentName, String program)
    {
       this.studentNo = studentNo;
       this.studentSurname = studentSurname;
       this.studentName = studentName;
       this.program = program;
    }

    Student(int studentNo, String studentSurname, String studentName, String program) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    public int getStudentNo()
    {
        return studentNo;
    }
    public String getstudentSurname()
    {
        return studentSurname;
    }
    public String getStudentName()
    {
        return studentName;
    }
    public String getProgram()
    {
        return program;
    }
    public String toString()
    {
        return studentNo+" "+studentSurname+" "+studentName+" "+program;
    }
    
    
}
public class ToDoList 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
      
        List<Student> c = new ArrayList<Student>();
        
        System.out.println("Welcome to your To-do Manager!\n");
        System.out.println("Please Enter your Name: ");
        
        //this Scanner is for the Integer
        Scanner a = new Scanner(System.in);
        
        //this Scanner is for the String
        Scanner b = new Scanner(System.in);
        
        String name = a.next();
        System.out.println("Hello "+name);
        String choice = null;
        String[] task = new String[10];

         do{
             //Display the Menu
              System.out.println("Please choose an option\n");
              System.out.println("");
              System.out.println("1. Add ");
              System.out.println("2. List all tasks ");
              System.out.println("3. Search ");
              System.out.println("4. Update ");
              System.out.println("5. Delete ");
              
              choice = b.nextLine();

              switch(choice) 
              {
                case "1": 
                  System.out.print("Enter Student Number: ");
                  int studentNo = a.nextInt();
                 
                  System.out.print("Enter Student Surname: ");
                  String studentSurname = b.nextLine();
                 
                  System.out.print("Enter Student Name: ");
                  String studentName = b.nextLine();
                 
                  System.out.print("Enter Program: ");
                  String program = b.nextLine();
                 
                 
                 //choice = input.nextLine();
                 
                  c.add(new Student(studentNo,studentSurname,studentName,program));
                break;
                 
                case "2":
                  System.out.println("---------------------------- ");
                  Iterator<Student> i = c.iterator();
                 while(i.hasNext())
                 {
                    Student s = i.next();
                    System.out.println(s);
                 }
                  System.out.println("---------------------------- ");
              break;
                
              case "3":
                   boolean found = false;
                   System.out.println("Enter StudentNo to Search: ");
                   studentNo = a.nextInt();
                   System.out.println("---------------------------- ");
                   i = c.iterator();
                  while(i.hasNext())
                  {
                    Student s = i.next();
                    if(s.getStudentNo() == studentNo)
                    {
                        System.out.println(s);
                        found = true;
                    }
                  }
                   if(!found)
                   {
                      System.out.println("Record not Found"); 
                   }
                   System.out.println("---------------------------- ");
              break;
                
              case "4":
                  found = false;
                   System.out.println("Enter StudentNo to Update: ");
                   studentNo = a.nextInt();
                   ListIterator<Student>li = c.listIterator();
                  while(li.hasNext())
                  {
                    Student s = li.next();
                    if(s.getStudentNo() == studentNo)
                    {
                        
                        System.out.print("Enter new Student Number: ");
                        studentNo = a.nextInt();
                        
                        System.out.print("Enter new Student Surname: ");
                        studentSurname = b.nextLine();
                        
                        System.out.print("Enter new Student Name: ");
                        studentName = b.nextLine();
                        
                        System.out.print("Enter new Program: ");
                        program = b.nextLine();
                        
                        li.set(new Student(studentNo,studentSurname,studentName,program));
                        
                        found = true;
                    }
                  }
                   if(!found)
                   {
                      System.out.println("Record not Found"); 
                   }
                   else
                   {
                       System.out.println("Record is Updated Successfully....!!");
                   }
              break;
                
              case "5":
                   found = false;
                   System.out.println("Enter StudentNo to Delete: ");
                   studentNo = a.nextInt();
                   System.out.println("---------------------------- ");
                   i = c.iterator();
                  while(i.hasNext())
                  {
                    Student s = i.next();
                    if(s.getStudentNo() == studentNo)
                    {
                        i.remove();
                        found = true;
                    }
                  }
                   if(!found)
                   {
                      System.out.println("Record not Found"); 
                   }
                   else
                   {
                       System.out.println("Record is Deleted Successfully....!!");
                   }
                   System.out.println("---------------------------- ");
              break;

              }
         }
              while (Integer.parseInt (choice) > 0);
                
                    System.out.println("Exit");
                
         
         
              }
         }
    